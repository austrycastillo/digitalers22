// let nombre = window.prompt("Hola, escribe tu nombre");
// let contenedorA = document.querySelector(".contenedorA");
// contenedorA.innerHTML = "Hola " + nombre;