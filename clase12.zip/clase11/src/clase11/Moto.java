package clase11;
//subclase o clase hija, derivada
public class Moto extends Vehiculo {

}
