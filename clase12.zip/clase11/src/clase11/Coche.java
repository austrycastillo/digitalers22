package clase11;
//clase deriva
public class Coche extends Vehiculo {

}
