package clase11;

//clase encapsulada
public class Persona {
	// atributos
	private String nombre;
	private String apellido;
	private int dni;
	private int edad;
	private String correo;

	// setters y getters
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getApellido() {
		return this.apellido;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public int getDni() {
		return this.dni;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	public int getEdad() {
		return this.edad;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getCorreo() {
		return this.correo;
	}
}
