package clase11;
//subclase
public class Bus extends Vehiculo {

}
