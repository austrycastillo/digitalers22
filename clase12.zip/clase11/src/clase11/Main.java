package clase11;

public class Main {

	public static void main(String[] args) {
		//instanciamos la clase Perro para crear objetos
		/*Perro perro1 = new Perro();//objeto 1
		perro1.comer();//objeto 1 está invocando al método comer
		//perro1.nombre = "Dalí";//solo funciona si es público
		perro1.setNombre("Toronto");//atributo privado
		//perro1.raza = "Yorki";//solo funciona si es público
		perro1.setRaza("Mestizo");
		//perro1.altura = 20.5;//solo funciona si es público
		perro1.setAltura(10);
		System.out.println(perro1.dormir());
		Perro perro2 = new Perro();//objeto 2
		//perro2.nombre="Bom";//solo funciona si es público
		perro2.setNombre("Rocco");
		System.out.println(perro2.dormir());
		System.out.println("Mi perrito se llama " + perro1.getNombre() 
		+ ", mide " + perro1.getAltura() + " cm de altura y es de raza " 
				+ perro1.getRaza());
		//probando a la clase persona
		System.out.println("************PERSONA************");
		Persona p1 = new Persona();
		p1.setNombre("Austry");
		p1.setApellido("Castillo");
		p1.setDni(12345678);
		p1.setCorreo("austry.castillo@educacionit.com");
		p1.setEdad(40);
		System.out.println("Mi nombre es " + p1.getNombre() + " " 
		+ p1.getApellido() + " tengo " + p1.getEdad() + " años de edad, dni: "
				+ p1.getDni() + " y mi correo es " + p1.getCorreo());
		*/
		
		
		
		
		
		
		//CLASE 12
		
		
		
		
		/*con setter*/
		 Perro miPerrito1 = new Perro();//mi objeto
		miPerrito1.setNombre("Laqui");
		System.out.println(miPerrito1.getNombre());
		
		Perro miPerrito2 = new Perro("León","Domerman",0.40);//mi objeto
		System.out.println(miPerrito2.getNombre());
		
		miPerrito1.comer();
		miPerrito1.comer("zanahorias");
		
		//instanciando la clase hueso
		Hueso hueso1 = new Hueso("jamón ahumado");
		Hueso hueso2 = new Hueso();
		hueso2.setSabor("pollo");
		System.out.println(hueso1.getSabor());
		hueso1.jugar();
		hueso2.jugar("esconderse");
		
		//instanciando la clase Perro
		Perro p3 = new Perro("Dante","Metizo",0.95,hueso1);
		Perro p4 = new Perro();
		p4.setHueso(hueso2);
		System.out.println(hueso1.toString());
		System.out.println(p3.toString());
		
		//construyendo un objeto de tipo Vehiculo (padre)
		Vehiculo vehiculo = new Vehiculo("Audi",100);
		System.out.println(vehiculo.toString());
		
		//construyendo un objeto de tipo Moto (hija)
		Moto moto = new Moto();
		moto.setMarca("Yamaha");
		moto.setPrecio(50);
		System.out.println("La moto " + moto.getMarca() + " cuesta "+ moto.getPrecio());
		
		
		
		
		
		
		
		
	}

}
